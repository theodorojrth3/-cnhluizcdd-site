const MANGOFY_STATUS_URL = process.env.MANGOFY_STATUS_URL || "";

function jsonResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    },
    body: JSON.stringify(body),
  };
}

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
      },
      body: "",
    };
  }

  const apiKey = process.env.MANGOFY_API_KEY;
  const storeCode = process.env.MANGOFY_STORE_CODE;
  if (!apiKey || !storeCode) {
    return jsonResponse(500, {
      success: false,
      error: "Configure MANGOFY_API_KEY e MANGOFY_STORE_CODE nas variaveis do Netlify",
    });
  }

  let id = event.queryStringParameters?.id;
  if (event.httpMethod === "POST") {
    try {
      const body = event.body ? JSON.parse(event.body) : {};
      id = body?.id || body?.paymentId || id;
    } catch {}
  }

  if (!id) {
    return jsonResponse(400, { success: false, error: "Informe o id" });
  }

  if (!MANGOFY_STATUS_URL) {
    return jsonResponse(200, {
      success: true,
      id,
      status: "pending",
      paid: false,
      message: "Status endpoint nao configurado (MANGOFY_STATUS_URL).",
    });
  }

  const statusResp = await fetch(`${MANGOFY_STATUS_URL.replace(/\/+$/, "")}/${encodeURIComponent(id)}`, {
    method: "GET",
    headers: {
      Authorization: apiKey,
      "Store-Code": storeCode,
    },
  });

  const text = await statusResp.text();
  let data = {};
  try {
    data = JSON.parse(text);
  } catch {
    data = {};
  }

  if (!statusResp.ok) {
    return jsonResponse(statusResp.status, { success: false, error: text || "Erro ao consultar pagamento" });
  }

  const status = data?.status || "pending";
  return jsonResponse(200, {
    success: true,
    id,
    status,
    paid: status === "paid" || status === "approved",
    raw: data,
  });
};
