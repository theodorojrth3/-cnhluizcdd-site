const MANGOFY_URL = process.env.MANGOFY_API_URL || "https://checkout.mangofy.com.br/api/v1/payment";

function jsonResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    },
    body: JSON.stringify(body),
  };
}

function normalizeAmount(rawAmount) {
  if (rawAmount == null) return { amountCents: 100, amountNum: 1 };
  if (typeof rawAmount === "string") {
    const cleaned = rawAmount.replace(/[^\d,.-]/g, "").replace(",", ".");
    const n = parseFloat(cleaned);
    if (!Number.isFinite(n)) return { amountCents: 100, amountNum: 1 };
    return { amountCents: Math.max(1, Math.round(n * 100)), amountNum: n };
  }
  const n = Number(rawAmount);
  if (!Number.isFinite(n)) return { amountCents: 100, amountNum: 1 };
  if (Number.isInteger(n) && n >= 1000) {
    const num = n / 100;
    return { amountCents: Math.max(1, Math.round(num * 100)), amountNum: num };
  }
  return { amountCents: Math.max(1, Math.round(n * 100)), amountNum: n };
}

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
      },
      body: "",
    };
  }

  const apiKey = process.env.MANGOFY_API_KEY;
  const storeCode = process.env.MANGOFY_STORE_CODE;
  if (!apiKey || !storeCode) {
    return jsonResponse(500, {
      success: false,
      error: "Configure MANGOFY_API_KEY e MANGOFY_STORE_CODE nas variaveis do Netlify",
    });
  }

  let body = {};
  try {
    body = event.body ? JSON.parse(event.body) : {};
  } catch {
    body = {};
  }

  const randDigits = (len) => Array.from({ length: len }, () => Math.floor(Math.random() * 10)).join("");
  const randId = randDigits(6);
  const rawAmount = 72.57;
  const { amountCents, amountNum } = normalizeAmount(rawAmount);
  const customerName = (body.nome || body.name || body.customer_name || `Cliente ${randId}`).toString();
  const customerEmail = (body.email || body.customer_email || `cliente${randId}@example.com`).toString();
  const customerPhone = (body.phone || body.customer_phone || `11${randDigits(9)}`).toString().replace(/\D/g, "");
  const cpfRaw = (body.cpf || body.document || body.customer_cpf || randDigits(11)).toString().replace(/\D/g, "");
  const customerCpf = cpfRaw.padEnd(11, "0").slice(0, 11);
  const tracking = (body.tracking || body.rastreio || body.codigo || `pedido-${randId}`).toString();
  const description = "Assinatura ";

  const expiresInDaysRaw = body.expires_in_days ?? body.expiresInDays ?? 1;
  const expiresInDaysNum = Math.min(30, Math.max(1, Number(expiresInDaysRaw) || 1));
  const paymentFormat = (body.payment_format || body.paymentFormat || "regular").toString();

  const host = event.headers?.host || "localhost";
  const proto = event.headers?.["x-forwarded-proto"] || "https";
  const postbackUrl = process.env.POSTBACK_URL || `${proto}://${host}/api/notify-approved`;
  const forwardedFor = event.headers?.["x-forwarded-for"] || "";
  const customerIp = forwardedFor.split(",")[0].trim();

  const payload = {
    store_code: storeCode,
    external_code: tracking,
    payment_method: "pix",
    payment_format: paymentFormat,
    installments: 1,
    payment_amount: amountCents,
    postback_url: postbackUrl,
    customer: {
      name: customerName,
      email: customerEmail,
      phone: customerPhone,
      document: customerCpf,
      ip: customerIp || "127.0.0.1",
    },
    items: [
      {
        title: description,
        quantity: 1,
        unit_price: amountCents,
      },
    ],
    pix: {
      expires_in_days: expiresInDaysNum,
    },
  };

  const mangofyResp = await fetch(MANGOFY_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: apiKey,
      "Store-Code": storeCode,
    },
    body: JSON.stringify(payload),
  });

  const text = await mangofyResp.text();
  if (!mangofyResp.ok) {
    return jsonResponse(mangofyResp.status, { success: false, error: text || "Erro ao criar PIX" });
  }

  let data = {};
  try {
    data = JSON.parse(text);
  } catch {
    data = {};
  }

  const pixData = data?.pix || {};
  const pixCopy =
    pixData?.pix_copy_and_paste ||
    data?.pix_copy_and_paste ||
    pixData?.pix_qrcode_text ||
    data?.pix_qrcode_text ||
    pixData?.brcode ||
    pixData?.payload ||
    data?.brcode ||
    data?.payload ||
    null;
  const qrcodeFinal =
    pixData?.pix_qrcode ||
    data?.pix_qrcode ||
    pixData?.qrcode ||
    pixData?.qr_code ||
    pixData?.payload ||
    pixCopy;
  const paymentId =
    data?.id ||
    data?.payment_id ||
    data?.paymentId ||
    data?.transaction_id ||
    data?.transactionId ||
    data?.external_code ||
    null;
  const expiresAt = pixData?.pix_expiration_date || data?.pix_expiration_date || null;

  return jsonResponse(200, {
    success: true,
    pix_code: pixCopy,
    transaction_id: paymentId,
    deposit_id: paymentId,
    qrcode: qrcodeFinal,
    amount: amountNum,
    key: pixData?.key || data?.key || null,
    brcode: pixCopy,
    payload: pixCopy,
    pixCode: pixCopy,
    pix: {
      key: pixData?.key || data?.key || null,
      brcode: pixCopy,
      qrcode: qrcodeFinal,
      payload: pixCopy,
    },
    pix_expiration_date: expiresAt,
    raw: data,
  });
};
