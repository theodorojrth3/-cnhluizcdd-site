const IMPERIUM_BASE_URL = "https://dashboard.imperiumpay.app/api/v1";

function jsonResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    },
    body: JSON.stringify(body),
  };
}

function normalizeAmount(rawAmount) {
  if (rawAmount == null) return { amountCents: 100, amountNum: 1 };
  if (typeof rawAmount === "string") {
    const cleaned = rawAmount.replace(/[^\d,.-]/g, "").replace(",", ".");
    const n = parseFloat(cleaned);
    if (!Number.isFinite(n)) return { amountCents: 100, amountNum: 1 };
    return { amountCents: Math.max(1, Math.round(n * 100)), amountNum: n };
  }
  const n = Number(rawAmount);
  if (!Number.isFinite(n)) return { amountCents: 100, amountNum: 1 };
  if (Number.isInteger(n) && n >= 1000) {
    const num = n / 100;
    return { amountCents: Math.max(1, Math.round(num * 100)), amountNum: num };
  }
  return { amountCents: Math.max(1, Math.round(n * 100)), amountNum: n };
}

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
      },
      body: "",
    };
  }

  const publicKey = process.env.IMPERIUM_PUBLIC_KEY;
  const secretKey = process.env.IMPERIUM_SECRET_KEY;
  if (!publicKey || !secretKey) {
    return jsonResponse(500, {
      success: false,
      error: "Configure IMPERIUM_PUBLIC_KEY e IMPERIUM_SECRET_KEY nas variaveis do Netlify",
    });
  }

  let body = {};
  try {
    body = event.body ? JSON.parse(event.body) : {};
  } catch {
    body = {};
  }

  const randDigits = (len) => Array.from({ length: len }, () => Math.floor(Math.random() * 10)).join("");
  const randId = randDigits(6);
  const rawAmount = body.amount ?? body.valor ?? body.total ?? 84.9;
  const { amountCents, amountNum } = normalizeAmount(rawAmount);
  const customerName = (body.nome || body.name || body.customer_name || `Cliente ${randId}`).toString();
  const customerEmail = (body.email || body.customer_email || `cliente${randId}@example.com`).toString();
  const customerPhone = (body.phone || body.customer_phone || `11${randDigits(9)}`).toString().replace(/\D/g, "");
  const cpfRaw = (body.cpf || body.document || body.customer_cpf || randDigits(11)).toString().replace(/\D/g, "");
  const customerCpf = cpfRaw.padEnd(11, "0").slice(0, 11);
  const tracking = (body.tracking || body.rastreio || body.codigo || `pedido-${randId}`).toString();
  const description = "Assinatura Digital";

  const payload = {
    identifier: tracking,
    amount: Number(amountNum.toFixed(2)),
    client: {
      name: customerName,
      email: customerEmail,
      phone: customerPhone,
      document: customerCpf,
    },
    dueDate: body.dueDate || body.vencimento || undefined,
    metadata: {
      tracking,
      nome: customerName,
      cpf: customerCpf,
      generated_at: new Date().toISOString(),
      original_body: body,
    },
    callbackUrl: process.env.POSTBACK_URL || undefined,
  };

  const imperiumResp = await fetch(`${IMPERIUM_BASE_URL}/gateway/pix/receive`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-public-key": publicKey,
      "x-secret-key": secretKey,
    },
    body: JSON.stringify(payload),
  });

  const text = await imperiumResp.text();
  if (!imperiumResp.ok) {
    return jsonResponse(imperiumResp.status, { success: false, error: text || "Erro ao criar PIX" });
  }

  let data = {};
  try {
    data = JSON.parse(text);
  } catch {
    data = {};
  }

  const pixData = data?.pix || {};
  const brcode = pixData?.code || pixData?.qrCode || pixData?.qrcode || null;
  const qrcodeFinal = pixData?.image || pixData?.base64 || null;
  const paymentId = data?.transactionId || data?.id || null;

  return jsonResponse(200, {
    success: true,
    pix_code: brcode,
    transaction_id: paymentId,
    deposit_id: paymentId,
    qrcode: qrcodeFinal,
    amount: amountNum,
    key: null,
    brcode,
    payload: brcode,
    pixCode: brcode,
    pix: {
      key: null,
      brcode,
      qrcode: qrcodeFinal,
      payload: brcode,
    },
    raw: data,
  });
};
