const IMPERIUM_BASE_URL = "https://dashboard.imperiumpay.app/api/v1";

function jsonResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    },
    body: JSON.stringify(body),
  };
}

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
      },
      body: "",
    };
  }

  const publicKey = process.env.IMPERIUM_PUBLIC_KEY;
  const secretKey = process.env.IMPERIUM_SECRET_KEY;
  if (!publicKey || !secretKey) {
    return jsonResponse(500, {
      success: false,
      error: "Configure IMPERIUM_PUBLIC_KEY e IMPERIUM_SECRET_KEY nas variaveis do Netlify",
    });
  }

  let id = event.queryStringParameters?.id;
  if (event.httpMethod === "POST") {
    try {
      const body = event.body ? JSON.parse(event.body) : {};
      id = body?.id || body?.paymentId || id;
    } catch {}
  }

  if (!id) {
    return jsonResponse(400, { success: false, error: "Informe o id" });
  }

  const url = new URL(`${IMPERIUM_BASE_URL}/gateway/transactions`);
  url.searchParams.set("id", id);
  const statusResp = await fetch(url.toString(), {
    method: "GET",
    headers: {
      "x-public-key": publicKey,
      "x-secret-key": secretKey,
    },
  });

  const text = await statusResp.text();
  let data = {};
  try {
    data = JSON.parse(text);
  } catch {
    data = {};
  }

  if (!statusResp.ok) {
    return jsonResponse(statusResp.status, { success: false, error: text || "Erro ao consultar pagamento" });
  }

  const status = data?.status || "PENDING";
  return jsonResponse(200, {
    success: true,
    id,
    status,
    paid: status === "COMPLETED",
    raw: data,
  });
};
